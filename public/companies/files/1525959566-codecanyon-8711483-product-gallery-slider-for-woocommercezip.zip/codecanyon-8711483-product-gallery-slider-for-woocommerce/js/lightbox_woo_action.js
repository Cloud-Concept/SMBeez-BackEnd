lightbox.option({
      'alwaysShowNavOnTouchDevices': (parseInt(mcWooLightBoxParam.w_slider_alwaysShowNavOnTouchDevices)) ? true :false,
      'disableScrolling': (parseInt(mcWooLightBoxParam.w_slider_disableScrolling)) ? true :false,
	  'showImageNumberLabel': (parseInt(mcWooLightBoxParam.w_slider_showImageNumberLabel)) ? true :false,
	  'wrapAround': (parseInt(mcWooLightBoxParam.w_slider_wrapAround)) ? true :false,
	  'fadeDuration': (parseInt(mcWooLightBoxParam.w_slider_fadeDuration)) ? (parseInt(mcWooLightBoxParam.w_slider_fadeDuration)) :500,
	  'positionFromTop': (parseInt(mcWooLightBoxParam.w_slider_positionFromTop)) ? (parseInt(mcWooLightBoxParam.w_slider_positionFromTop)) :50,
	  'resizeDuration': (parseInt(mcWooLightBoxParam.w_slider_resizeDuration)) ? (parseInt(mcWooLightBoxParam.w_slider_resizeDuration)) :700,
    })